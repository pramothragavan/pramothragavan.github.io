# The GAP package aisemirings

TODO: add a description of your package; perhaps also instructions how how to
install and use it, resp. where to find out more


## Contact

TODO: add info on how to contact you and/or how to report issues with your
package

## License

TODO: Provide information on the license of your package. A license is
important as it determines who has a right to distribute your package. The
"default" license to consider is GNU General Public License v2 or later, as
that is the license of GAP itself.
